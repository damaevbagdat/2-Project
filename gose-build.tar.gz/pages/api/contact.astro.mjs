import fs from 'fs/promises';
import path from 'path';
import fetch from 'node-fetch';
export { renderers } from '../../renderers.mjs';

const LEVELS = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
  silent: 100
};
function envLevel() {
  const v = (process.env.LOG_LEVEL || "info").toLowerCase();
  if (v === "debug" || v === "info" || v === "warn" || v === "error" || v === "silent") return v;
  return "info";
}
const CURRENT = envLevel();
function shouldLog(level) {
  return LEVELS[level] >= LEVELS[CURRENT];
}
function formatMessage(level, msg) {
  const base = { level, time: (/* @__PURE__ */ new Date()).toISOString() };
  if (typeof msg === "string") return JSON.stringify({ ...base, msg });
  try {
    return JSON.stringify({ ...base, msg });
  } catch {
    return JSON.stringify({ ...base, msg: String(msg) });
  }
}
const logger = {
  debug: (m) => {
    if (shouldLog("debug")) console.debug(formatMessage("debug", m));
  },
  info: (m) => {
    if (shouldLog("info")) console.info(formatMessage("info", m));
  },
  warn: (m) => {
    if (shouldLog("warn")) console.warn(formatMessage("warn", m));
  },
  error: (m) => {
    if (shouldLog("error")) console.error(formatMessage("error", m));
  }
};

function buildEmailHTML(submission) {
  const { name, email, phone, service, message, createdAt } = submission;
  return `
  <html>
    <body style="font-family: Arial, sans-serif; color: #0A2342;">
      <h2>New contact submission</h2>
      <p><strong>Name:</strong> ${escapeHtml(name)}</p>
      <p><strong>Email:</strong> ${escapeHtml(email)}</p>
      ${phone ? `<p><strong>Phone:</strong> ${escapeHtml(phone)}</p>` : ""}
      ${service ? `<p><strong>Service:</strong> ${escapeHtml(service)}</p>` : ""}
      <p><strong>Message:</strong></p>
      <div style="border-left:4px solid #DDD; padding-left:12px;">${escapeHtml(message).replace(/\n/g, "<br/>")}</div>
      <hr/>
      <small>Received: ${escapeHtml(createdAt)}</small>
    </body>
  </html>
  `;
}
function escapeHtml(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

const DATA_DIR = path.resolve(process.cwd(), "data");
const FILE_PATH = path.join(DATA_DIR, "submissions.json");
function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
async function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
async function retrySend(fn, attempts = 3, backoff = 300) {
  let lastErr;
  for (let i = 0; i < attempts; i++) {
    try {
      return await fn();
    } catch (e) {
      lastErr = e;
      const wait = backoff * Math.pow(2, i);
      await delay(wait);
    }
  }
  throw lastErr;
}
const POST = async ({ request }) => {
  try {
    const body = await request.json();
    const { name, email, phone, service, message, consent } = body;
    const errors = [];
    if (!name || String(name).trim().length < 2) errors.push("name");
    if (!email || !validateEmail(String(email))) errors.push("email");
    if (!message || String(message).trim().length < 5) errors.push("message");
    if (consent !== true && consent !== "true") errors.push("consent");
    if (errors.length) {
      return new Response(JSON.stringify({ success: false, errors }), {
        status: 400
      });
    }
    const submission = {
      id: Date.now(),
      name: String(name).trim(),
      email: String(email).trim(),
      phone: phone ? String(phone).trim() : null,
      service: service ? String(service).trim() : null,
      message: String(message).trim(),
      consent: true,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    try {
      await fs.mkdir(DATA_DIR, { recursive: true });
      const exists = await fs.stat(FILE_PATH).then(() => true).catch(() => false);
      if (!exists) {
        await fs.writeFile(
          FILE_PATH,
          JSON.stringify([submission], null, 2),
          "utf-8"
        );
      } else {
        const raw = await fs.readFile(FILE_PATH, "utf-8");
        const arr = JSON.parse(raw || "[]");
        arr.push(submission);
        await fs.writeFile(FILE_PATH, JSON.stringify(arr, null, 2), "utf-8");
      }
    } catch (e) {
      logger.warn({ msg: "Failed to persist contact submission to local file", error: String(e) });
    }
    (async () => {
      try {
        if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
          try {
            const nodemailer = await import('nodemailer');
            const transporter = nodemailer.createTransport({
              host: process.env.SMTP_HOST,
              port: Number(process.env.SMTP_PORT) || 587,
              secure: (process.env.SMTP_SECURE || "false") === "true",
              auth: {
                user: process.env.SMTP_USER,
                pass: process.env.SMTP_PASS
              }
            });
            const send = async () => transporter.sendMail({
              from: process.env.SMTP_FROM || process.env.SMTP_USER,
              to: process.env.CONTACT_TO || process.env.SMTP_USER,
              subject: `New contact from ${submission.name}`,
              text: `${submission.name} <${submission.email}>

${submission.message}`,
              html: buildEmailHTML(submission)
            });
            await retrySend(send, 3);
            logger.info({ msg: "Sent contact via SMTP", to: process.env.CONTACT_TO || process.env.SMTP_USER });
          } catch (e) {
            logger.warn({ msg: "SMTP send failed", error: String(e) });
          }
        }
        if (process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID) {
          try {
            const token = process.env.TELEGRAM_BOT_TOKEN;
            const chatId = process.env.TELEGRAM_CHAT_ID;
            const text = `New contact from ${submission.name}
${submission.email}

${submission.message}`;
            const url = `https://api.telegram.org/bot${token}/sendMessage`;
            await fetch(url, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ chat_id: chatId, text })
            });
            logger.info({ msg: "Sent contact via Telegram", chatId });
          } catch (e) {
            logger.warn({ msg: "Telegram send failed", error: String(e) });
          }
        }
      } catch (e) {
        logger.warn({ msg: "Notification send task failed", error: String(e) });
      }
    })();
    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (err) {
    logger.error({ msg: "Contact API unexpected error", error: String(err) });
    return new Response(JSON.stringify({ success: false }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
