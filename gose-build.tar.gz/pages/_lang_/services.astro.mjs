import { c as createComponent, a as createAstro, r as renderComponent, b as renderTemplate, m as maybeRenderHead, d as addAttribute } from '../../chunks/astro/server_CHqft7i7.mjs';
import 'kleur/colors';
import { $ as $$BaseLayout, t } from '../../chunks/BaseLayout_C63iMFHZ.mjs';
import { a as getCollection } from '../../chunks/_astro_content_BttWtfCT.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro();
async function getStaticPaths() {
  const locales = ["ru", "kz", "en"];
  return locales.map((l) => ({ params: { lang: l } }));
}
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  const locale = Astro2.params.lang;
  const allServices = await getCollection("services");
  const localeServices = allServices.filter((s) => s.data.locale === locale);
  const publishedServices = localeServices.filter((s) => !s.data.draft).sort((a, b) => (a.data.order ?? 0) - (b.data.order ?? 0));
  const localizedContent = {
    ru: {
      title: "\u041D\u0430\u0448\u0438 \u0443\u0441\u043B\u0443\u0433\u0438 - Alash-Zan \u042E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0444\u0438\u0440\u043C\u0430",
      description: "\u0428\u0438\u0440\u043E\u043A\u0438\u0439 \u0441\u043F\u0435\u043A\u0442\u0440 \u044E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0443\u0441\u043B\u0443\u0433 \u043E\u0442 \u0432\u0435\u0434\u0443\u0449\u0435\u0439 \u044E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0444\u0438\u0440\u043C\u044B \u0432 \u041A\u0430\u0437\u0430\u0445\u0441\u0442\u0430\u043D\u0435. \u041A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u043D\u043E\u0435 \u043F\u0440\u0430\u0432\u043E, \u0441\u0443\u0434\u0435\u0431\u043D\u0430\u044F \u043F\u0440\u0430\u043A\u0442\u0438\u043A\u0430 \u0438 \u0434\u0440\u0443\u0433\u0438\u0435 \u0443\u0441\u043B\u0443\u0433\u0438."
    },
    en: {
      title: "Our Services - Alash-Zan Legal Firm",
      description: "A comprehensive range of legal services from the leading law firm in Kazakhstan. Corporate law, litigation, and more."
    },
    kz: {
      title: "\u049A\u044B\u0437\u043C\u0435\u0442\u0442\u0435\u0440\u0456\u043C\u0456\u0437 - Alash-Zan \u0417\u0430\u04A3\u0434\u044B\u049B \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u044F",
      description: "\u049A\u0430\u0437\u0430\u049B\u0441\u0442\u0430\u043D\u043D\u044B\u04A3 \u0436\u0435\u0442\u0435\u043A\u0448\u0456 \u0437\u0430\u04A3\u0434\u044B\u049B \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u044F\u0441\u044B\u043D\u044B\u04A3 \u043A\u0435\u04A3 \u0430\u0443\u049B\u044B\u043C\u0434\u044B \u0437\u0430\u04A3\u0434\u044B\u049B \u049B\u044B\u0437\u043C\u0435\u0442\u0442\u0435\u0440\u0456. \u041A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0442\u0456\u043A \u049B\u04B1\u049B\u044B\u049B, \u0441\u043E\u0442 \u0442\u04D9\u0436\u0456\u0440\u0438\u0431\u0435\u0441\u0456 \u0436\u04D9\u043D\u0435 \u0431\u0430\u0441\u049B\u0430\u043B\u0430\u0440."
    }
  };
  const content = localizedContent[locale] || localizedContent.ru;
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "lang": locale, "title": content.title, "description": content.description }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="container"> <section class="services-list"> <h1>${t("services.pageTitle", locale)}</h1> <div class="services-grid"> ${publishedServices.map((service) => renderTemplate`<a${addAttribute(`/${locale}/services/${service.slug}`, "href")} class="service-card"${addAttribute(service.slug, "key")}> <h2>${service.data.title}</h2> <p>${service.data.description}</p> </a>`)} </div> </section> </div> ` })}`;
}, "C:/Users/damae/OneDrive/\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/GitHub/2-Project/src/pages/[lang]/services/index.astro", void 0);

const $$file = "C:/Users/damae/OneDrive/Документы/GitHub/2-Project/src/pages/[lang]/services/index.astro";
const $$url = "/[lang]/services";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
