import { c as createComponent, a as createAstro, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../../../chunks/astro/server_CHqft7i7.mjs';
import 'kleur/colors';
import { $ as $$BaseLayout } from '../../../chunks/BaseLayout_C63iMFHZ.mjs';
import { a as getCollection } from '../../../chunks/_astro_content_BttWtfCT.mjs';
export { renderers } from '../../../renderers.mjs';

const $$Astro = createAstro();
async function getStaticPaths() {
  const locales = ["ru", "kz", "en"];
  const all = await getCollection("services");
  const paths = [];
  for (const l of locales) {
    const localeServices = all.filter((s) => s.data.locale === l);
    const slugs = Array.from(new Set(localeServices.map((s) => s.slug)));
    for (const s of slugs) {
      paths.push({ params: { lang: l, slug: s } });
    }
  }
  return paths;
}
const $$slug = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$slug;
  const locale = Astro2.params.lang;
  const slug = Astro2.params.slug;
  const allServices = await getCollection("services");
  const localeServices = allServices.filter((s) => s.data.locale === locale);
  let service = localeServices.find((s) => s.slug === slug);
  let serviceFound = true;
  let Content = null;
  if (!service) {
    serviceFound = false;
  } else {
    const rendered = await service.render();
    Content = rendered.Content;
  }
  const localizedNotFound = {
    ru: { title: "404 \u2014 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E", message: `\u0423\u0441\u043B\u0443\u0433\u0430 \u0441 \u043A\u043B\u044E\u0447\u043E\u043C "${slug}" \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430 \u0434\u043B\u044F \u043B\u043E\u043A\u0430\u043B\u0438 "${locale}".` },
    kz: { title: "404 \u2014 \u0442\u0430\u0431\u044B\u043B\u043C\u0430\u0434\u044B", message: `"${locale}" \u0442\u0456\u043B\u0456 \u04AF\u0448\u0456\u043D "${slug}" \u043A\u0456\u043B\u0442\u0456 \u0431\u0430\u0440 \u049B\u044B\u0437\u043C\u0435\u0442 \u0442\u0430\u0431\u044B\u043B\u043C\u0430\u0434\u044B.` },
    en: { title: "404 \u2014 not found", message: `Service with key "${slug}" not found for locale "${locale}".` }
  };
  const notFoundContent = localizedNotFound[locale] || localizedNotFound.ru;
  let title = notFoundContent.title;
  let description = `\u0421\u0442\u0440\u0430\u043D\u0438\u0446\u0430 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430 \u0434\u043B\u044F \u0443\u0441\u043B\u0443\u0433\u0438 "${slug}" - Alash-Zan \u042E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0444\u0438\u0440\u043C\u0430`;
  if (serviceFound && service) {
    title = `${service.data.title} - Alash-Zan \u042E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0444\u0438\u0440\u043C\u0430`;
    description = service.data.description || `\u0423\u0441\u043B\u0443\u0433\u0430 "${service.data.title}" \u043E\u0442 Alash-Zan, \u0432\u0435\u0434\u0443\u0449\u0435\u0439 \u044E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0444\u0438\u0440\u043C\u044B \u0432 \u041A\u0430\u0437\u0430\u0445\u0441\u0442\u0430\u043D\u0435.`;
  }
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "lang": locale, "title": title, "description": description }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="container"> ${serviceFound ? renderTemplate`<article class="service-detail"> <header> <h1>${service.data.title}</h1> ${service.data.description && renderTemplate`<p class="lead">${service.data.description}</p>`} </header> <section class="service-body"> ${renderComponent($$result2, "Content", Content, {})} </section> </article>` : renderTemplate`<section class="not-found"> <h1>${notFoundContent.title}</h1> <p>${notFoundContent.message}</p> </section>`} </div> ` })}`;
}, "C:/Users/damae/OneDrive/\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/GitHub/2-Project/src/pages/[lang]/services/[slug].astro", void 0);

const $$file = "C:/Users/damae/OneDrive/Документы/GitHub/2-Project/src/pages/[lang]/services/[slug].astro";
const $$url = "/[lang]/services/[slug]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$slug,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
