import { c as createComponent, a as createAstro, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_CHqft7i7.mjs';
import 'kleur/colors';
import { $ as $$BaseLayout } from '../../chunks/BaseLayout_C63iMFHZ.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro();
async function getStaticPaths() {
  const locales = ["ru", "kz", "en"];
  return locales.map((l) => ({ params: { lang: l } }));
}
const $$Contact = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Contact;
  const locale = Astro2.params.lang;
  const { getCollection } = await import('../../chunks/_astro_content_BttWtfCT.mjs').then(n => n._);
  let Content = null;
  let pageData = null;
  const pages = await getCollection("pages");
  let entry = pages.find((p) => (p.data?.locale ?? "") === locale && /contact/i.test(p.id));
  if (!entry) entry = pages.find((p) => /contact/i.test(p.id));
  if (entry) {
    const rendered = await entry.render();
    Content = rendered.Content;
    pageData = entry.data;
  }
  const title = pageData?.title || "\u041A\u043E\u043D\u0442\u0430\u043A\u0442\u044B";
  const description = pageData?.description || "\u0421\u0432\u044F\u0436\u0438\u0442\u0435\u0441\u044C \u0441 \u043D\u0430\u043C\u0438 - Alash-Zan, \u044E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0444\u0438\u0440\u043C\u0430 \u043F\u0440\u0435\u043C\u0438\u0443\u043C-\u043A\u043B\u0430\u0441\u0441\u0430 \u0432 \u041A\u0430\u0437\u0430\u0445\u0441\u0442\u0430\u043D\u0435. \u041D\u0430\u0448\u0438 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u044B, \u0430\u0434\u0440\u0435\u0441 \u0438 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u0434\u043B\u044F \u0441\u0432\u044F\u0437\u0438.";
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "lang": locale, "title": title, "description": description }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="container"> <article class="contact-page"> <div class="contact-info"> ${renderComponent($$result2, "Content", Content, {})} </div> </article> </div> ` })}`;
}, "C:/Users/damae/OneDrive/\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/GitHub/2-Project/src/pages/[lang]/contact.astro", void 0);

const $$file = "C:/Users/damae/OneDrive/Документы/GitHub/2-Project/src/pages/[lang]/contact.astro";
const $$url = "/[lang]/contact";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Contact,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
