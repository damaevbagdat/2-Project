import { c as createComponent, a as createAstro, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_CHqft7i7.mjs';
import 'kleur/colors';
import { $ as $$BaseLayout } from '../../chunks/BaseLayout_C63iMFHZ.mjs';
import { a as getCollection } from '../../chunks/_astro_content_BttWtfCT.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro();
async function getStaticPaths() {
  const locales = ["ru", "kz", "en"];
  return locales.map((l) => ({ params: { lang: l } }));
}
const $$About = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$About;
  const locale = Astro2.params.lang;
  const pages = await getCollection("pages");
  let entry = pages.find(
    (page) => page.id.startsWith("about-") && page.data.locale === locale
  );
  if (!entry) {
    entry = pages.find(
      (page) => page.id.startsWith("about-") && page.data.locale === "ru"
    );
  }
  let Content = null;
  let pageData = null;
  if (entry) {
    const rendered = await entry.render();
    Content = rendered.Content;
    pageData = entry.data;
  }
  const title = pageData?.title || "\u041E \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438";
  const description = pageData?.description || "Alash-Zan - \u0432\u0435\u0434\u0443\u0449\u0430\u044F \u044E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0444\u0438\u0440\u043C\u0430 \u0432 \u041A\u0430\u0437\u0430\u0445\u0441\u0442\u0430\u043D\u0435, \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0437\u0438\u0440\u0443\u044E\u0449\u0430\u044F\u0441\u044F \u043D\u0430 \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u043D\u043E\u043C \u043F\u0440\u0430\u0432\u0435, \u0441\u0443\u0434\u0435\u0431\u043D\u044B\u0445 \u0441\u043F\u043E\u0440\u0430\u0445 \u0438 \u043A\u043E\u043C\u043F\u043B\u0430\u0435\u043D\u0441\u0435.";
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "lang": locale, "title": title, "description": description }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="container"> <article class="about-page"> <h1>${title}</h1> <div class="content"> ${renderComponent($$result2, "Content", Content, {})} </div> </article> </div> ` })}`;
}, "C:/Users/damae/OneDrive/\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/GitHub/2-Project/src/pages/[lang]/about.astro", void 0);

const $$file = "C:/Users/damae/OneDrive/Документы/GitHub/2-Project/src/pages/[lang]/about.astro";
const $$url = "/[lang]/about";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$About,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
