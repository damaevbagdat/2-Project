import { c as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead, d as addAttribute } from '../chunks/astro/server_CHqft7i7.mjs';
import 'kleur/colors';
import { $ as $$BaseLayout } from '../chunks/BaseLayout_C63iMFHZ.mjs';
import { a as getCollection } from '../chunks/_astro_content_BttWtfCT.mjs';
/* empty css                                 */
export { renderers } from '../renderers.mjs';

const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const publishedServices = (await getCollection("services", ({ data }) => {
    return data.draft !== true;
  })).sort((a, b) => (a.data.order ?? 0) - (b.data.order ?? 0));
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "data-astro-cid-52q5xhqt": true }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="container" data-astro-cid-52q5xhqt> <section class="services-list" data-astro-cid-52q5xhqt> <h1 data-astro-cid-52q5xhqt>Наши услуги</h1> <p class="services-intro" data-astro-cid-52q5xhqt>Мы предлагаем широкий спектр юридических услуг для физических и юридических лиц</p> <div class="services-grid" data-astro-cid-52q5xhqt> ${publishedServices.map((service) => renderTemplate`<a${addAttribute(`/services/${service.slug}`, "href")} class="service-card"${addAttribute(service.slug, "key")} data-astro-cid-52q5xhqt> <h2 data-astro-cid-52q5xhqt>${service.data.title}</h2> <p data-astro-cid-52q5xhqt>${service.data.description}</p> <span class="service-category" data-astro-cid-52q5xhqt>${service.data.category}</span> </a>`)} </div> </section> </div> ` })} `;
}, "C:/Users/damae/OneDrive/\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/GitHub/2-Project/src/pages/services/index.astro", void 0);

const $$file = "C:/Users/damae/OneDrive/Документы/GitHub/2-Project/src/pages/services/index.astro";
const $$url = "/services";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
