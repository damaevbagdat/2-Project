import { c as createComponent, a as createAstro, m as maybeRenderHead, b as renderTemplate, e as renderScript, r as renderComponent } from '../chunks/astro/server_CHqft7i7.mjs';
import 'kleur/colors';
import { t, $ as $$BaseLayout } from '../chunks/BaseLayout_C63iMFHZ.mjs';
import 'clsx';
/* empty css                                 */
/* empty css                                 */
export { renderers } from '../renderers.mjs';

const $$Astro$5 = createAstro();
const $$Hero = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$Hero;
  const { lang = "ru" } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<section class="hero" data-astro-cid-bbe6dxrz> <div class="hero-content" data-astro-cid-bbe6dxrz> <h1 class="hero-title" data-astro-cid-bbe6dxrz>${t("hero.title", lang)}</h1> <p class="hero-subtitle" data-astro-cid-bbe6dxrz>${t("hero.subtitle", lang)}</p> <a href="#contact" class="cta-button" data-astro-cid-bbe6dxrz>${t("hero.cta", lang)}</a> </div> </section> `;
}, "C:/Users/damae/OneDrive/\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/GitHub/2-Project/src/components/Hero.astro", void 0);

const $$Astro$4 = createAstro();
const $$PricingSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$PricingSection;
  const { lang = "ru" } = Astro2.props;
  const services = [
    { categoryKey: "pricing.service1.category", titleKey: "pricing.service1.title", priceKey: "pricing.service1.price" },
    { categoryKey: "pricing.service2.category", titleKey: "pricing.service2.title", priceKey: "pricing.service2.price" },
    { categoryKey: "pricing.service3.category", titleKey: "pricing.service3.title", priceKey: "pricing.service3.price" }
  ];
  return renderTemplate`${maybeRenderHead()}<section class="pricing-section" data-astro-cid-przegf2x> <div class="container" data-astro-cid-przegf2x> <h2 class="section-title" data-astro-cid-przegf2x>${t("sections.pricingTitle", lang)}</h2> <p class="section-subtitle" data-astro-cid-przegf2x>${t("sections.pricingSubtitle", lang)}</p> <div class="pricing-list" data-astro-cid-przegf2x> ${services.map((service) => renderTemplate`<div class="pricing-item" data-astro-cid-przegf2x> <div class="pricing-info" data-astro-cid-przegf2x> <span class="pricing-category" data-astro-cid-przegf2x>${t(service.categoryKey, lang)}</span> <h3 class="pricing-title" data-astro-cid-przegf2x>${t(service.titleKey, lang)}</h3> </div> <div class="pricing-price" data-astro-cid-przegf2x>${t(service.priceKey, lang)}</div> </div>`)} </div> </div> </section> `;
}, "C:/Users/damae/OneDrive/\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/GitHub/2-Project/src/components/PricingSection.astro", void 0);

const $$Astro$3 = createAstro();
const $$ProcessSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$ProcessSection;
  const { lang = "ru" } = Astro2.props;
  const steps = [
    { icon: "\u{1F527}", titleKey: "process.step1.title", descKey: "process.step1.desc" },
    { icon: "\u2699\uFE0F", titleKey: "process.step2.title", descKey: "process.step2.desc" },
    { icon: "\u23F1\uFE0F", titleKey: "process.step3.title", descKey: "process.step3.desc" }
  ];
  return renderTemplate`${maybeRenderHead()}<section class="process-section" data-astro-cid-25obxio5> <div class="container" data-astro-cid-25obxio5> <h2 class="section-title" data-astro-cid-25obxio5>${t("sections.processTitle", lang)}</h2> <p class="section-subtitle" data-astro-cid-25obxio5>${t("sections.processSubtitle", lang)}</p> <div class="process-grid" data-astro-cid-25obxio5> ${steps.map((step, index) => renderTemplate`<div class="process-step" data-astro-cid-25obxio5> <div class="step-icon" data-astro-cid-25obxio5>${step.icon}</div> <p class="step-desc" data-astro-cid-25obxio5>${t(step.descKey, lang)}</p> ${index < steps.length - 1 && renderTemplate`<div class="step-arrow" data-astro-cid-25obxio5>→</div>`} </div>`)} </div> </div> </section> `;
}, "C:/Users/damae/OneDrive/\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/GitHub/2-Project/src/components/ProcessSection.astro", void 0);

const $$Astro$2 = createAstro();
const $$AdvantagesSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$AdvantagesSection;
  const { lang = "ru" } = Astro2.props;
  const advantages = [
    { icon: "\u{1F468}\u200D\u{1F527}", titleKey: "advantages.adv1.title", descKey: "advantages.adv1.desc" },
    { icon: "\u{1F4E6}", titleKey: "advantages.adv4.title", descKey: "advantages.adv4.desc" },
    { icon: "\u{1F4B0}", titleKey: "advantages.adv5.title", descKey: "advantages.adv5.desc" }
  ];
  return renderTemplate`${maybeRenderHead()}<section class="advantages-section" data-astro-cid-3w44iv7r> <div class="container" data-astro-cid-3w44iv7r> <h2 class="section-title" data-astro-cid-3w44iv7r>${t("sections.advantagesTitle", lang)}</h2> <div class="advantages-grid" data-astro-cid-3w44iv7r> ${advantages.map((adv) => renderTemplate`<div class="advantage-card" data-astro-cid-3w44iv7r> <div class="advantage-icon" data-astro-cid-3w44iv7r>${adv.icon}</div> <h3 data-astro-cid-3w44iv7r>${t(adv.titleKey, lang)}</h3> <p data-astro-cid-3w44iv7r>${t(adv.descKey, lang)}</p> </div>`)} </div> </div> </section> `;
}, "C:/Users/damae/OneDrive/\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/GitHub/2-Project/src/components/AdvantagesSection.astro", void 0);

const $$Astro$1 = createAstro();
const $$ContactSection = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$ContactSection;
  const { lang = "ru" } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<section class="contact-section" id="contact" data-astro-cid-jjagjrbk> <div class="container" data-astro-cid-jjagjrbk> <h2 class="section-title" data-astro-cid-jjagjrbk>${t("sections.contactTitle", lang)}</h2> <div class="contact-container" data-astro-cid-jjagjrbk> <div class="contact-info" data-astro-cid-jjagjrbk> <h2 class="contact-subtitle" data-astro-cid-jjagjrbk>${t("contact.subtitle", lang)}</h2> <p class="contact-desc" data-astro-cid-jjagjrbk>${t("contact.desc", lang)}</p> <div class="social-links" data-astro-cid-jjagjrbk> <a href="https://wa.me/77479022293?text=Здравствуйте!%20Пишу%20с%20сайта%20remont-spectehniki.kz.%20" class="social-link" target="_blank" rel="noopener noreferrer" data-astro-cid-jjagjrbk> <span class="social-icon" data-astro-cid-jjagjrbk>📱</span> <div data-astro-cid-jjagjrbk> <strong data-astro-cid-jjagjrbk>WhatsApp</strong> <p data-astro-cid-jjagjrbk>${t("contact.whatsappDesc", lang)}</p> </div> </a> <a href="tel:+77479022293" class="social-link" data-astro-cid-jjagjrbk> <span class="social-icon" data-astro-cid-jjagjrbk>📞</span> <div data-astro-cid-jjagjrbk> <strong data-astro-cid-jjagjrbk>8 747 902 22 93</strong> <p data-astro-cid-jjagjrbk>${t("contact.phoneDesc", lang)}</p> </div> </a> <a href="tel:+77086899067" class="social-link" data-astro-cid-jjagjrbk> <span class="social-icon" data-astro-cid-jjagjrbk>📞</span> <div data-astro-cid-jjagjrbk> <strong data-astro-cid-jjagjrbk>8 708 689 90 67</strong> <p data-astro-cid-jjagjrbk>${t("contact.phoneDesc", lang)}</p> </div> </a> </div> </div> <div class="contact-form-wrapper" data-astro-cid-jjagjrbk> <h3 class="form-title" data-astro-cid-jjagjrbk>${t("contact.formTitle", lang)}</h3> <form class="contact-form" id="contact-form" data-astro-cid-jjagjrbk> <div class="form-group" data-astro-cid-jjagjrbk> <label data-astro-cid-jjagjrbk>${t("contact.formLabelName", lang)}</label> <input type="text" name="name" required data-astro-cid-jjagjrbk> </div> <div class="form-group" data-astro-cid-jjagjrbk> <label data-astro-cid-jjagjrbk>${t("contact.formLabelPhone", lang)}</label> <input type="tel" name="phone" required data-astro-cid-jjagjrbk> </div> <div class="form-group" data-astro-cid-jjagjrbk> <label data-astro-cid-jjagjrbk>${t("contact.formLabelMessage", lang)}</label> <textarea name="message" required data-astro-cid-jjagjrbk></textarea> </div> <button type="submit" class="cta-button form-submit" data-astro-cid-jjagjrbk>${t("contact.formSubmit", lang)}</button> </form> </div> </div> </div> </section>  ${renderScript($$result, "C:/Users/damae/OneDrive/\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/GitHub/2-Project/src/components/ContactSection.astro?astro&type=script&index=0&lang.ts")}`;
}, "C:/Users/damae/OneDrive/\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/GitHub/2-Project/src/components/ContactSection.astro", void 0);

const $$Astro = createAstro();
async function getStaticPaths() {
  const locales = ["ru", "kz", "en"];
  return locales.map((l) => ({ params: { lang: l } }));
}
const $$Index = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  const locale = Astro2.params.lang;
  const localizedContent = {
    ru: {
      title: "\u0420\u0435\u043C\u043E\u043D\u0442 \u0441\u043F\u0435\u0446\u0442\u0435\u0445\u043D\u0438\u043A\u0438 \u0438 \u0434\u0438\u0437\u0435\u043B\u044C\u043D\u044B\u0445 \u0434\u0432\u0438\u0433\u0430\u0442\u0435\u043B\u0435\u0439 \u0432 \u041A\u0430\u0437\u0430\u0445\u0441\u0442\u0430\u043D\u0435",
      description: "\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0439 \u0440\u0435\u043C\u043E\u043D\u0442 \u0441\u043F\u0435\u0446\u0442\u0435\u0445\u043D\u0438\u043A\u0438 \u0438 \u0434\u0438\u0437\u0435\u043B\u044C\u043D\u044B\u0445 \u0434\u0432\u0438\u0433\u0430\u0442\u0435\u043B\u0435\u0439. \u0414\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0430, \u0437\u0430\u043C\u0435\u043D\u0430 \u0434\u0435\u0442\u0430\u043B\u0435\u0439, \u043A\u0430\u043F\u0438\u0442\u0430\u043B\u044C\u043D\u044B\u0439 \u0440\u0435\u043C\u043E\u043D\u0442 \u0414\u0412\u0421. \u0413\u0438\u0431\u043A\u0438\u0435 \u0446\u0435\u043D\u044B, \u0437\u0430\u043F\u0447\u0430\u0441\u0442\u0438 \u0432 \u043D\u0430\u043B\u0438\u0447\u0438\u0438."
    },
    en: {
      title: "Heavy Equipment and Diesel Engine Repair in Kazakhstan",
      description: "Professional heavy equipment and diesel engine repair. Diagnostics, parts replacement, engine overhaul. Flexible prices, parts in stock."
    },
    kz: {
      title: "\u049A\u0430\u0437\u0430\u049B\u0441\u0442\u0430\u043D\u0434\u0430 \u0430\u0440\u043D\u0430\u0439\u044B \u0442\u0435\u0445\u043D\u0438\u043A\u0430 \u043C\u0435\u043D \u0434\u0438\u0437\u0435\u043B\u044C\u0434\u0456 \u049B\u043E\u0437\u0493\u0430\u043B\u0442\u049B\u044B\u0448\u0442\u0430\u0440\u0434\u044B \u0436\u04E9\u043D\u0434\u0435\u0443",
      description: "\u0410\u0440\u043D\u0430\u0439\u044B \u0442\u0435\u0445\u043D\u0438\u043A\u0430 \u043C\u0435\u043D \u0434\u0438\u0437\u0435\u043B\u044C\u0434\u0456 \u049B\u043E\u0437\u0493\u0430\u043B\u0442\u049B\u044B\u0448\u0442\u0430\u0440\u0434\u044B \u043A\u04D9\u0441\u0456\u0431\u0438 \u0436\u04E9\u043D\u0434\u0435\u0443. \u0414\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0430, \u0431\u04E9\u043B\u0448\u0435\u043A\u0442\u0435\u0440\u0434\u0456 \u0430\u0443\u044B\u0441\u0442\u044B\u0440\u0443, \u049B\u043E\u0437\u0493\u0430\u043B\u0442\u049B\u044B\u0448\u0442\u044B \u043A\u04AF\u0440\u0434\u0435\u043B\u0456 \u0436\u04E9\u043D\u0434\u0435\u0443. \u0418\u043A\u0435\u043C\u0434\u0456 \u0431\u0430\u0493\u0430\u043B\u0430\u0440, \u049B\u043E\u0441\u0430\u043B\u049B\u044B \u0431\u04E9\u043B\u0448\u0435\u043A\u0442\u0435\u0440 \u049B\u043E\u0440\u0434\u0430."
    }
  };
  const content = localizedContent[locale] || localizedContent.ru;
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "lang": locale, "title": content.title, "description": content.description }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Hero", $$Hero, { "lang": locale })} ${renderComponent($$result2, "PricingSection", $$PricingSection, { "lang": locale })} ${renderComponent($$result2, "ProcessSection", $$ProcessSection, { "lang": locale })} ${renderComponent($$result2, "AdvantagesSection", $$AdvantagesSection, { "lang": locale })} ${renderComponent($$result2, "ContactSection", $$ContactSection, { "lang": locale })} ` })} ${renderScript($$result, "C:/Users/damae/OneDrive/\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/GitHub/2-Project/src/pages/[lang]/index.astro?astro&type=script&index=0&lang.ts")}`;
}, "C:/Users/damae/OneDrive/\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/GitHub/2-Project/src/pages/[lang]/index.astro", void 0);

const $$file = "C:/Users/damae/OneDrive/Документы/GitHub/2-Project/src/pages/[lang]/index.astro";
const $$url = "/[lang]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
