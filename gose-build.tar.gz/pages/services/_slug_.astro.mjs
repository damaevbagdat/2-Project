import { c as createComponent, a as createAstro, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_CHqft7i7.mjs';
import 'kleur/colors';
import { g as getEntryBySlug, a as getCollection } from '../../chunks/_astro_content_BttWtfCT.mjs';
import { $ as $$BaseLayout, a as $$Header, b as $$Footer } from '../../chunks/BaseLayout_C63iMFHZ.mjs';
/* empty css                                     */
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro();
async function getStaticPaths() {
  const allServices = await getCollection("services");
  return allServices.map((service) => ({ params: { slug: service.slug } }));
}
const $$slug = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$slug;
  const service = await getEntryBySlug("services", Astro2.params.slug);
  if (!service) {
    throw new Error(`Service not found: ${Astro2.params.slug}`);
  }
  const rendered = await service.render();
  const { Content } = rendered;
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "data-astro-cid-tcy35dad": true }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "Header", $$Header, { "data-astro-cid-tcy35dad": true })} ${maybeRenderHead()}<main data-astro-cid-tcy35dad> <div class="container" data-astro-cid-tcy35dad> <article class="service-page" data-astro-cid-tcy35dad> <h1 data-astro-cid-tcy35dad>${service.data.title}</h1> <p class="service-description" data-astro-cid-tcy35dad>${service.data.description}</p> <div class="service-meta" data-astro-cid-tcy35dad> <span class="service-category" data-astro-cid-tcy35dad>Категория: ${service.data.category}</span> </div> <div class="service-content" data-astro-cid-tcy35dad> ${renderComponent($$result2, "Content", Content, { "data-astro-cid-tcy35dad": true })} </div> </article> </div> </main> ${renderComponent($$result2, "Footer", $$Footer, { "data-astro-cid-tcy35dad": true })} ` })} `;
}, "C:/Users/damae/OneDrive/\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B/GitHub/2-Project/src/pages/services/[slug].astro", void 0);

const $$file = "C:/Users/damae/OneDrive/Документы/GitHub/2-Project/src/pages/services/[slug].astro";
const $$url = "/services/[slug]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$slug,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
