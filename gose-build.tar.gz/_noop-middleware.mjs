const onRequest = (_, next) => next();

export { onRequest };
