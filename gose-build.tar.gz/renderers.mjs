const renderers = [];

export { renderers };
